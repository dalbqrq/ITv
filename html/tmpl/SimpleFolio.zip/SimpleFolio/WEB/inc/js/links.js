function textcollapse()
{
	var readmore = document.getElementById("readmore");
	var readless = document.getElementById("readless");
	{
		readmore.style.display = "none";
		readmore.style.display = "block";
	}
}
	
	